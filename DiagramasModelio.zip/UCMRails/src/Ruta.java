import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("ca6229dd-6424-4e36-ab79-9a4a56a868cb")
public class Ruta {
    @objid ("527b2a33-48ce-4efc-85c1-1b1e710ebbc0")
    private String nombre;

    @objid ("12972e17-64fd-4dbe-a7f6-edb44a2eba7f")
    private double precio;

    @objid ("f6def156-4f34-4e1c-b8b5-87b2cf142871")
    public List<Parada>  = new ArrayList<Parada> ();

    @objid ("44fe751f-017b-4ef5-bc29-3209a7d02e10")
    public List<Tren>  = new ArrayList<Tren> ();

    @objid ("fa7605f6-b60f-4ede-a823-323ab178611f")
    String getNombre() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.nombre;
    }

    @objid ("9ae6d180-81d7-4a8c-8923-10a675aff723")
    void setNombre(String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.nombre = value;
    }

    @objid ("98d6e54e-79c1-4341-817d-1e415a96944f")
    double getPrecio() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.precio;
    }

    @objid ("0d04e8e5-fc9d-45ff-94c9-2a141cd1e8ab")
    void setPrecio(double value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.precio = value;
    }

}
