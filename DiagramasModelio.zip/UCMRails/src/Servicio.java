import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("5096a9fb-8b11-44b0-b160-f84b2928fd10")
public class Servicio {
    @objid ("6fa4c017-3810-4ee6-994e-7bc34859ecd9")
    private String nombre;

    @objid ("1b3df57d-31d4-4a2d-ae79-13dd05a266c0")
    private double precio;

    @objid ("152a497e-5124-45fc-862d-96ff4770dd15")
    String getNombre() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.nombre;
    }

    @objid ("2815824b-dec3-4f13-bef6-f9a94867dfe0")
    void setNombre(String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.nombre = value;
    }

    @objid ("9c65662a-4f06-430d-8e9e-0d65e8ff2075")
    double getPrecio() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.precio;
    }

    @objid ("d7516518-c94e-4486-afc4-3528c7a0e39c")
    void setPrecio(double value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.precio = value;
    }

}
