import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("dbd7b14d-7505-4daa-8d7d-4c98982a10e6")
public class Estacion {
    @objid ("2ee8cd9e-2f0f-44b7-8ae7-14b8ef265baf")
    private String nombre;

    @objid ("a7371880-782a-4aa6-9fdb-cdd2c8c12e44")
    private String localidad;

}
