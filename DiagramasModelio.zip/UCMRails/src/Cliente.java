import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("ede1c75b-fb00-44b2-bb63-dc216b5b795a")
public class Cliente extends Usuario {
    @objid ("d5de843a-4583-4076-a6f5-2817b622dbd2")
    private double saldo;

    @objid ("e861c3a0-2acd-4441-b85e-16314de2bc90")
    public List<Billete> Es comprado = new ArrayList<Billete> ();

    @objid ("71fa541e-e78e-4dbb-9473-ab0bff58f40e")
    public void comprarBillete() {
    }

    @objid ("8d301ea5-e180-4b74-8ef5-708cccf89422")
    public void buscarViaje() {
    }

    @objid ("1ab3f5c3-b148-49b5-ae0a-a60bc266d8bf")
    public void anularBillete() {
    }

    @objid ("59725ae1-8e86-4c7e-80c9-9eb1ad593ca3")
    public void consultarBillete() {
    }

    @objid ("1c6f5ab7-7dcd-41fa-83ec-c6e5a5a5f268")
    public void valorar() {
    }

    @objid ("b35320f6-7cf8-4ef2-ae7f-bf5c79461f6f")
    double getSaldo() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.saldo;
    }

    @objid ("29f729c5-b4d5-448c-ad83-db78c4c35d15")
    public void addSaldo() {
    }

}
