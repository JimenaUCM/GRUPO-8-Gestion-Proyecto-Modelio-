import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("69087989-9432-4461-9c28-79b602d282e7")
public class Usuario {
    @objid ("706ea50f-cfd1-4e0c-aec5-b3eb1f436487")
    protected String nombre;

    @objid ("61ac48f1-f478-4b52-8863-25580f9fe3c1")
    protected String apellidos;

    @objid ("faf545b5-806b-41df-9f5d-aae4c58d2038")
    protected String dni;

    @objid ("95d93b92-0fdd-4d4d-9f04-074cae27a105")
    protected String contrasena;

    @objid ("d05033fc-f528-4af1-a2c5-e6cd7b36648a")
    public void darDeAlta() {
    }

    @objid ("a195a567-3314-4ff4-997d-e0fdcb627c8f")
    public void darDeBaja() {
    }

}
