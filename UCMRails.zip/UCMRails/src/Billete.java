import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("3dd5cd74-24a6-44ad-b7d0-f79cb861d9fb")
public class Billete {
    @objid ("7ad0459c-cce8-4219-809c-930ec601c071")
    private int numeroAsiento;

    @objid ("410ce2e6-ac05-4755-95c2-7b9ee17cce59")
    private Date fecha;

    @objid ("4c996295-441b-4465-bcc6-343da9969990")
    private double precio;

    @objid ("dd4d40d5-111d-4446-88bb-175b8a40142e")
    private int numVagon;

    @objid ("aafdc014-23eb-44c3-b6cc-278468bf8541")
    private int valoracion;

    @objid ("1ac75856-e0b8-4031-828a-5720bf45aad2")
    private boolean estaDisponible;

    @objid ("45b4c76e-5981-423d-a823-196e4ade9def")
    public List<Servicio>  = new ArrayList<Servicio> ();

    @objid ("544ffd33-22bd-435c-ac0f-32c7a73dd739")
    public Cliente Comprador;

    @objid ("6030efd4-0f78-405d-88c1-c36c038a8bba")
    boolean isEstaDisponible() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.estaDisponible;
    }

    @objid ("24c805a7-3768-4b04-80cd-a908d1f7a1e1")
    void setEstaDisponible(boolean value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.estaDisponible = value;
    }

    @objid ("d51bb1e9-055d-4cb6-ae1c-f476a4b67bce")
    int getNumeroAsiento() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.numeroAsiento;
    }

    @objid ("7fe7f95c-f7bf-4f43-b081-928e9e6c4638")
    Date getFecha() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.fecha;
    }

    @objid ("6ffe31e7-3549-45a7-a5eb-ad4d22295835")
    int getNumVagon() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.numVagon;
    }

    @objid ("055a799e-ae1b-43d5-a5fe-95aa7a0c7fdd")
    int getValoracion() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.valoracion;
    }

    @objid ("6ac34812-4a92-4c63-bb86-3b4586a79745")
    void setValoracion(int value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.valoracion = value;
    }

}
