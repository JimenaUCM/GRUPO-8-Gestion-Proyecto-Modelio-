import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("5ace8ba6-94eb-4bd1-9662-fe553c80318b")
public class Parada {
    @objid ("8ccff6fc-05ab-428f-9c52-0aee69537d26")
    private String hora;

    @objid ("7817d782-657f-45b7-b7b3-40795da94b7d")
    public Estacion Tiene;

}
