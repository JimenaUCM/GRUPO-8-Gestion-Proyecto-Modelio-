import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("ea150590-954a-4dc8-912e-05623fd2f925")
public class Administrador extends Usuario {
    @objid ("5fe373c7-a392-4dcd-88ba-28b2b61d8943")
    public List<Ruta>  = new ArrayList<Ruta> ();

    @objid ("d601db9f-ee8f-4e68-b25d-d21fbc50d8d8")
    public void anadirRuta(Ruta ruta) {
    }

    @objid ("b18375fc-df02-41fe-b1ce-939a812510a9")
    public void quitarRuta() {
    }

    @objid ("a1cd8e77-e8aa-4907-a089-b00bca7e09d5")
    public void quitarEstacion() {
    }

    @objid ("da241f31-b998-4121-a3c9-0f9d34243c50")
    public void anadirEstacion(Estacion estacion) {
    }

    @objid ("a92721a4-4dba-4b5b-9627-63c65647caaf")
    public void anadirTren(String tren) {
    }

    @objid ("2c855c1f-6d8d-4c69-8fdf-b7bcc51c68f6")
    public void quitarTren() {
    }

}
