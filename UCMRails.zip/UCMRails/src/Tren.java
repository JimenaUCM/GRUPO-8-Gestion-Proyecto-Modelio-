import java.util.ArrayList;
import java.util.List;
import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("771cc6a1-757d-4c84-9156-1d6e75b8387c")
public class Tren {
    @objid ("2ebebfb6-fe60-4f11-ac10-049d424eba97")
    private String id;

    @objid ("ae48e0c7-09fc-4040-819a-e37191977b0a")
    public TipoTren ;

    @objid ("b5237a27-39b5-4edb-bfcc-3b3b652318a8")
    public Ruta ;

    @objid ("8df4bce5-34c8-44b6-8ea3-0907bcdb68cc")
    public List<Billete> billete = new ArrayList<Billete> ();

    @objid ("8d5cf704-846d-447c-bcc0-516912653e27")
    String getId() {
        // Automatically generated method. Please delete this comment before entering specific code.
        return this.id;
    }

    @objid ("71bf8589-1ae7-4dd5-9c3f-3ed9283c4eab")
    void setId(String value) {
        // Automatically generated method. Please delete this comment before entering specific code.
        this.id = value;
    }

}
