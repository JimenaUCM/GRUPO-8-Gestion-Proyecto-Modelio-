import com.modeliosoft.modelio.javadesigner.annotations.objid;

@objid ("d70143c4-b5ce-48f9-8627-86fd8c72ac45")
public enum TipoTren {
    Alta Velocidad,
    Standar,
    Economico;
}
